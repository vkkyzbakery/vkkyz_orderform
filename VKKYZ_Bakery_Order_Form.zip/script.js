
window.onload = function() {
    let deliveryTimeSelect = document.querySelector('select[name="deliveryTime"]');
    for (let hour = 9; hour <= 20; hour++) {
        deliveryTimeSelect.innerHTML += `<option value="${hour}:00">${hour}:00</option>`;
        deliveryTimeSelect.innerHTML += `<option value="${hour}:30">${hour}:30</option>`;
    }
};

function previewOrder() {
    const form = document.getElementById('orderForm');
    let previewDiv = document.getElementById('previewOrder');
    previewDiv.innerHTML = `<strong>Preview:</strong><br>Name: ${form.name.value}<br>WhatsApp: ${form.contact.value}<br>Address: ${form.address.value}<br>`;
}

document.getElementById('orderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    if (confirm('Confirm your order submission. Account number will be sent via WhatsApp.')) {
        alert('Thank you for ordering! Your order has been submitted.');
        this.reset();
    }
});
