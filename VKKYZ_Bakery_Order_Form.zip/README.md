
# VKKYZ Bakery Order Form

A beautiful order form for VKKYZ Bakery customers.

## Features:
- Cupcakes, Cakes, Loaf Cakes ordering
- Light cream theme
- Large order handling
- Delivery time and date selection
- Preview before submitting
- Watermark with VKKYZ logo

## How to Use
Just open the `index.html` in your browser.

## Setup
You can host it on GitHub Pages or Vercel easily!

